import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';

@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.css']
})
export class ChildComponent implements OnInit {
@Input() message:string;
sendmessage:string="from child recived"
@Output() msg= new EventEmitter<string>();
  constructor() { }

  ngOnInit() {
  }
  sendMessage(){
    this.msg.emit(this.sendmessage);
  }
}
