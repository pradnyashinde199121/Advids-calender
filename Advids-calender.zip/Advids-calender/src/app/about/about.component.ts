import { Component, OnInit } from '@angular/core';
import{employee} from '../../../../employee';
import { from } from 'rxjs';
import { PreloadingStrategy } from '@angular/router';
@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
employees:employee[];
search:string;
  constructor() { }

  ngOnInit() {
    this.employees = [{id:1, name:"pradnya", salary:30000},
    {id:2, name:"aradnya", salary:40000},
    {id:3, name:"bradnya", salary:60000},
    {id:4, name:"cradnya", salary:60000}
    


    ];
  }

}
