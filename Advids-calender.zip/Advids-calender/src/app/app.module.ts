import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HerosComponent } from './heros/heros.component';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { GalleryComponent } from './gallery/gallery.component';
import { SearchtextPipe } from './searchtext.pipe';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { MymoduleModule } from './mymodule/mymodule.module';
import{MyserviceService} from'./myservice.service';
import {ViewModule} from './view/view.module';
@NgModule({
  declarations: [
    AppComponent,
    HerosComponent,
    HomeComponent,
    AboutComponent,
    GalleryComponent,
    SearchtextPipe,
    ParentComponent,
    ChildComponent,
  
   
  ],
  imports: [
    BrowserModule,
    MymoduleModule,
    AppRoutingModule,
    ViewModule,
    FormsModule,
    ServiceWorkerModule.register('ngsw-worker.js', { enabled: environment.production })
  ],
  providers: [MyserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
