import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BehaviorSubject  } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class MyserviceService {

  constructor() { 
 
  }
  method1():any {
    return[{name:"pradnya",snazme:"shinde"},{name:"Amar",sname:"shinde1"},{name:"advita",sname:"1shinde"}];
  }
  public name=new BehaviorSubject(null); //object create
  method2(data){this.name.next(data);
    
  }
}
