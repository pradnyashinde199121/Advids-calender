import { Component, OnInit } from '@angular/core';
import{MyserviceService} from'../myservice.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  topics=['first','second','third'];
  constructor(private myservice1 :MyserviceService) { 
 
  }
public data:[];
method1(){
this.data=this.myservice1.method1(); //display data in html from service
console.log(this.data);
}
method3(variable1){
  this.myservice1.method2(variable1);
}
  ngOnInit() {
    this.method1();
    
  }

}
