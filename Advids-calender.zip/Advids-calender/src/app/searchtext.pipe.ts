import { Pipe, PipeTransform } from '@angular/core';
import{employee} from'../../../employee'
@Pipe({
  name: 'searchtext'
})
export class SearchtextPipe implements PipeTransform {

  transform(employees: employee[], searchtext: string): any {
    if(!employees || !searchtext)
     {
return employees;
     }
    return  employees.filter(emp=> 
      emp.name.toUpperCase() == searchtext.toUpperCase());
  }

}
