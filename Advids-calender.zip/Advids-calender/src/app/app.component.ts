import { Component } from '@angular/core';
declare var $: any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'easyfullcalendar';
  name ='';
  startDate='';
  endDate='';
  type='';
  slot='';
  typeData=['WFH','emergency','Seek'];
  timeSlot=['Morning','Afternoon','Day'];
  records:any=[];
  record:any={ };
ngOnInit(){
  this.displayCalender();
  
   }
   clearDate(){
    if(this.slot== "Morning" ||this.slot=="Afernoon")
    {
     this.endDate = this.startDate;
    }
    
  }
   getData(){
    this.record={};
    this.records=[];
     this.record.title=this.type.concat(' '+this.slot),
     this.records.slot=this.slot;
     this.record.description=this.name;
     this.record.start=this.startDate;
     this.record.end=this.endDate;
     this.records.push(this.record);
     $("#calendar").fullCalendar( 'addEventSource', this.records )
   }
   
   DeleteData(){
    
$('#calendar').fullCalendar('removeEventSources');
   }
   displayCalender(){
    setTimeout(() => {
       
      $("#calendar").fullCalendar({  
                      header: {
                          left   : 'prev,next today',
                          center : 'title ',
                          right  : 'month,agendaWeek,agendaDay'
                      },
                      navLinks   : true,
                      editable   : true,
                      eventLimit : true,
                      
                      eventRender: function(event:any, element:any, view) {
                        if(event.title.substring(0,3) == "WFH") {
                          element.css('background-color', '#008000');

                      }
                    else  if(event.title.substring(0,9) == "emergency") {
                        element.css('background-color', '#FF0000');
                        
                    }
                   else  if(event.title.substring(0,4) == "Seek") {
                      element.css('background-color', '#FFFF00');
                      
                  }
                  
                        element.find('span.fc-title').attr('data-toggle', 'tooltip');  
                       
                         element.find('span.fc-title').attr('title', event.title);   
                         element.find('span.fc-event-title').html(element.find('span.fc-event-title').text());  
                     },
                      events: this.records,
                      
                      eventClick: function (calEvent, jsEvent, view) {           
    $('#calendar').fullCalendar('removeEvents', calEvent._id);
}
                  }).on('click', '.fc-agendaWeek-button, .fc-month-button, .fc-agendaDay-button, .fc-prev-button, .fc-next-button', function() {
 $('[data-toggle="tooltip"]').tooltip();
});
                  $('[data-toggle="tooltip"]').tooltip();
   }, 100);
   }
   
}