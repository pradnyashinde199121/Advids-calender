import { SearchtextPipe } from './searchtext.pipe';

describe('SearchtextPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchtextPipe();
    expect(pipe).toBeTruthy();
  });
});
