import { Component, OnInit } from '@angular/core';
import{MyserviceService} from '../myservice.service';
@Component({
  selector: 'app-gallery',
  templateUrl: './gallery.component.html',
  styleUrls: ['./gallery.component.css']
})
export class GalleryComponent implements OnInit {

  constructor(private myservice1 :MyserviceService) { }
  public data:[];
  method4(){
  this.myservice1.name.subscribe(s=> this.data=s);
 }
  ngOnInit() {
    this.method4();
  }

}
