export class Heros {
    id: number;
    name: string;
  }